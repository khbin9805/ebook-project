from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from flask_paginate import Pagination
import MySQLdb.cursors
import re
import random

app = Flask(__name__, static_folder='static')

app.secret_key = 'your secret key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'book'

mysql = MySQL(app)

@app.route("/main")
def main():
	if 'loggedin' in session:
		return render_template("main.html")

@app.route('/')
def home():
    cursor = mysql.connection.cursor()
    # Retrieve the 10 latest books from your database
    query = "SELECT * FROM book ORDER BY publishdate DESC LIMIT 10"
    cursor.execute(query)
    latest_books = cursor.fetchall()
    cursor.close()
    # Randomly select 3 books to display
    new_books = random.sample(latest_books, 3)
    cursor = mysql.connection.cursor()
    query = "SELECT * FROM book"
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    recommended_books = random.sample(results, 3)
    return render_template('main.html', 
                            new_books=new_books,
                            recommended_book_1=recommended_books[0], 
                            recommended_book_2=recommended_books[1], 
                            recommended_book_3=recommended_books[2])

@app.route('/search')
def search():
    keyword = request.args.get('keyword', '')
    if keyword:
        cursor = mysql.connection.cursor()
        query = f"SELECT * FROM book WHERE name LIKE '%{keyword}%'"
        cursor.execute(query)
        results = cursor.fetchall()
        cursor.close()
    else:
        results = []
    return render_template('booklist.html', results=results)

@app.route('/books/genre/<string:genre>')
def book_by_genre(genre):
    page = int(request.args.get('page', 1))
    per_page = 10
    offset = (page - 1) * per_page
    
    cursor = mysql.connection.cursor()
    query = "SELECT * FROM book WHERE TRIM(genre) = %s LIMIT %s OFFSET %s"
    cursor.execute(query, (genre, per_page, offset,))
    results = cursor.fetchall()
    cursor.close()

    total = len(results)
    pagination = Pagination(page=page, per_page=per_page, total=total, css_framework='bootstrap4')

    return render_template('books.html', results=results, pagination=pagination)

@app.route('/books/<int:number>')
def book_detail(number):
    cursor = mysql.connection.cursor()
    query = "SELECT * FROM book WHERE number = %s"
    cursor.execute(query, (number,))
    result = cursor.fetchone()
    cursor.close()

    return render_template('book.html', result=result)

@app.route('/recommended_book')
def recommended_book():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM book ORDER BY RAND() LIMIT 1")
    recommended_book = cursor.fetchone()
    cursor.close()
    return render_template('recommended_book.html', recommended_book=recommended_book)

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'account' in request.form and 'password' in request.form:
        account = request.form['account']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute(
            'SELECT * FROM user WHERE account = % s AND password = % s', 
            (account, password)
        )
        user = cursor.fetchone()
        if user:
            session['loggedin'] = True
            session['account'] = user['account']
            session['password'] = user['password']
            msg = 'Logged in successfully!'
            cursor = mysql.connection.cursor()
            cursor.execute(
                'SELECT * FROM book ORDER BY publishdate DESC LIMIT 10'
            )
            latest_books = cursor.fetchall()
            cursor.close()
            new_books = random.sample(latest_books, 3)
            cursor = mysql.connection.cursor()
            cursor.execute('SELECT * FROM book')
            results = cursor.fetchall()
            cursor.close()
            recommended_books = random.sample(results, 3)
            return render_template(
                'main.html', 
                new_books=new_books,
                recommended_book_1=recommended_books[0], 
                recommended_book_2=recommended_books[1], 
                recommended_book_3=recommended_books[2]
            )
        else:
            msg = 'Incorrect username/password!'
    return render_template('login.html', msg=msg)


@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('account', None)
    session.pop('password', None)
    cursor = mysql.connection.cursor()
    # Retrieve the 10 latest books from your database
    query = "SELECT * FROM book ORDER BY publishdate DESC LIMIT 10"
    cursor.execute(query)
    latest_books = cursor.fetchall()
    cursor.close()
    # Randomly select 3 books to display
    new_books = random.sample(latest_books, 3)
    cursor = mysql.connection.cursor()
    query = "SELECT * FROM book"
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    recommended_books = random.sample(results, 3)
    return render_template('main.html', 
                            new_books=new_books,
                            recommended_book_1=recommended_books[0], 
                            recommended_book_2=recommended_books[1], 
                            recommended_book_3=recommended_books[2])

@app.route('/signup', methods=['GET', 'POST'])
def signup():
	msg = ''
	if request.method == 'POST' \
	and 'account' in request.form \
	and 'password' in request.form \
    and 'username' in request.form \
    and 'email' in request.form \
	and 'gender' in request.form \
	and 'birth' in request.form \
	and 'phonenumber' in request.form:
		account = request.form['account']
		password = request.form['password']
		username = request.form['username']
		email = request.form['email']
		gender = request.form['gender']
		birth = request.form['birth']
		phonenumber = request.form['phonenumber']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute(
			'SELECT * FROM user WHERE account = % s', (account, ))
		user = cursor.fetchone()
		if user:
			msg = '이미 존재하는 계정입니다 !'
		elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
			msg = '이메일 형식에 맞지 않습니다 !'
		elif not re.match(r'^[a-zA-Z0-9가-힣]+$', username):
			msg = '이름은 영어와 숫자, 한글로만 구성되어야 한다 !'
		else:
			cursor.execute('INSERT INTO user VALUES \
		        (% s, % s, % s, % s, % s, % s, % s)', 
               (account, password, username, email, gender, birth, phonenumber))
			mysql.connection.commit()
			msg = '가입을 환영합니다 !'
			return redirect('/login')
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	return render_template('signup.html', msg=msg)

@app.route('/password-retrieval', methods=['GET', 'POST'])
def password_retrieval():
    msg = ''
    if request.method == 'POST' and 'account' in request.form:
        account = request.form['account']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute(
            'SELECT * FROM user WHERE account = % s', (account, ))
        user = cursor.fetchone()
        if user:
            # 임시 비밀번호 생성 및 업데이트
            import random
            import string
            temp_password = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
            cursor.execute(
                'UPDATE user SET password = %s WHERE account = %s',
                (temp_password, account))
            mysql.connection.commit()
            
            # 결과를 바로 출력
            msg = f"임시 비밀번호는 {temp_password}입니다."
        else:
            msg = '존재하지 않는 계정입니다.'
    elif request.method == 'POST':
        msg = '계정을 입력해주세요.'
    return render_template('password-retrieval.html', msg=msg)

@app.route("/update", methods=['GET', 'POST'])
def update():
    msg = ''
    if 'loggedin' in session:
        if request.method == 'POST':
            if '' in [request.form[field] for field in ['password', 'username', 'email', 'gender', 'birth', 'phonenumber']]:
                msg = 'Please fill out the form !'
            else:
                account = session['account']
                password = request.form['password']
                username = request.form['username']
                email = request.form['email']
                gender = request.form['gender']
                birth = request.form['birth']
                phonenumber = request.form['phonenumber']
                cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
                cursor.execute(
                    'UPDATE user SET password=%s, username=%s, email=%s, gender=%s, birth=%s, phonenumber=%s WHERE account=%s', 
                    (password, username, email, gender, birth, phonenumber, account))
                mysql.connection.commit()
                msg = '내 정보 수정이 완료되었습니다'
        return render_template("mypage.html")
    return redirect(url_for('update.html'))

@app.route("/update_result")
def update_result():
    msg = request.args.get('msg')
    return render_template("update_result.html", msg=msg)

@app.route('/mypage')
def mypage():
    if 'loggedin' not in session:
        return redirect(url_for('login', next='/mypage'))
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM user WHERE account = % s', (session['account'], ))
    user = cursor.fetchone()
    
    return render_template('mypage.html', user=user)
    # return render_template('mypage.html')

if __name__ == '__main__':
    app.run(debug=True)
