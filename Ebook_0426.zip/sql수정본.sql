CREATE TABLE `users`(
    `user_id` INT(30) NOT NULL,
    `username` VARCHAR(255) NOT NULL,
    `password` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `gender` VARCHAR(10) NOT NULL,
    `birth` DATE NOT NULL,
    `phonenumber` VARCHAR(30) NOT NULL
);
ALTER TABLE
    `user` ADD PRIMARY KEY(`user_id`);

CREATE TABLE `purchase`(
    `purchase_id` INT(30) NOT NULL,
    `user_id` INT(30) NOT NULL,
    `book_id` VARCHAR(100) NOT NULL,
    `purchase_name` VARCHAR(100) NOT NULL,
    `purchase_date` DATE NOT NULL,
    `purchase_price` BIGINT NOT NULL
);
ALTER TABLE
    `purchase` ADD PRIMARY KEY(`purrchase_id`);

CREATE TABLE `books`(
    `book_id` INT(30) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `author` VARCHAR(50) NOT NULL,
    `publisher` VARCHAR(50) NOT NULL,
    `publishdate` DATE NOT NULL,
    `price` INT NOT NULL,
    `description` TEXT NOT NULL,
    `image` VARCHAR(255) NOT NULL,
    `genre` CHAR
);
ALTER TABLE
    `book` ADD PRIMARY KEY(`book_id`);

CREATE TABLE 'bucket'(
    `bucket_id` INT(30),
    `user_id` INT(30),
    `book_id` INT(30),
    `book_name` VARCHAR(100),
    `book_author` VARCHAR(50),
    `book_publisher` VARCHAR(50)
);
ALTER TABLE
    `book` ADD PRIMARY KEY(`bucket_id`);


-- drop table 할때 외래키 오류시 외래키 삭제 방법
-- ALTER TABLE mylibrary DROP FOREIGN KEY mylibrary_book_number_foreign;

mysql --local-infile=1 -u root -p

LOAD DATA LOCAL INFILE 'C:\bookdb.csv'
INTO TABLE book
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;