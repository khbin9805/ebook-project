from flask import Flask, render_template, request
import MySQLdb

# MySQL 연결 정보
host = 'localhost'
user = 'root'
password = 'root'
database = 'book'

# Flask 애플리케이션 생성
app = Flask(__name__)

# MySQL 연결 설정
db = MySQLdb.connect(host=host, user=user, password=password, db=database)

# 라우팅 설정
@app.route('/')
def index():
    return render_template('booklist.html')

@app.route('/books')
def books():
    # 검색어 가져오기
    keyword = request.args.get('keyword', '')
    # MySQL 쿼리 실행
    cursor = db.cursor()
    query = f"SELECT * FROM book WHERE title LIKE '%{keyword}%'"
    cursor.execute(query)
    results = cursor.fetchall()
    # 검색 결과 렌더링
    return render_template('books.html', results=results)

# 애플리케이션 실행
if __name__ == '__main__':
    app.run(debug=True)
