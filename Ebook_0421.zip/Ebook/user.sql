create database ebook default character set utf8 collate utf8_general_ci;
use ebook

create table user (
    account char(30) not null,
    password varchar(255) not null,
    username varchar(50) not null,
    email varchar(100) not null,
    gender varchar(10) not null,
    birth date not null,
    phonenumber varchar(30),
    primary key(account)
) engine=InnoDB default charset=utf8;

