from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re

app = Flask(__name__, static_folder='static')

app.secret_key = 'your secret key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '1234'
app.config['MYSQL_DB'] = 'ebook'

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('main.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
	msg = ''
	if request.method == 'POST' and 'account' in request.form and 'password' in request.form:
		account = request.form['account']
		password = request.form['password']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute(
			'SELECT * FROM user WHERE account = % s \
			AND password = % s', (account, password, ))
		user = cursor.fetchone()
		if user:
			session['loggedin'] = True
			session['account'] = user['account']
			session['password'] = user['password']
			msg = 'Logged in successfully !'
			return render_template('main.html', msg=msg)
		else:
			msg = 'Incorrect username / password !'
	return render_template('login.html', msg=msg)


@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('account', None)
    session.pop('password', None)
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
	msg = ''
	if request.method == 'POST' \
	and 'account' in request.form \
	and 'password' in request.form \
    and 'username' in request.form \
    and 'email' in request.form \
	and 'gender' in request.form \
	and 'birth' in request.form \
	and 'phonenumber' in request.form:
		account = request.form['account']
		password = request.form['password']
		username = request.form['username']
		email = request.form['email']
		gender = request.form['gender']
		birth = request.form['birth']
		phonenumber = request.form['phonenumber']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute(
			'SELECT * FROM user WHERE account = % s', (account, ))
		user = cursor.fetchone()
		if user:
			msg = '이미 존재하는 계정입니다 !'
		elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
			msg = 'Email 형식에 맞지 않습니다 !'
		elif not re.match(r'[A-Za-z0-9]+', username):
			msg = 'name must contain only characters and numbers !'
		else:
			cursor.execute('INSERT INTO user VALUES \
		        (% s, % s, % s, % s, % s, % s, % s)', 
               (account, password, username, email, gender, birth, phonenumber))
			mysql.connection.commit()
			msg = '가입을 환영합니다 !'
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	return render_template('signup.html', msg=msg)

@app.route("/main")
def index():
	if 'loggedin' in session:
		return render_template("main.html")
	return redirect(url_for('login'))


@app.route('/mypage.html')
def mypage():
    return render_template('mypage.html')
if __name__ == '__main__':
    app.run(debug=True)
