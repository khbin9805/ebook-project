CREATE TABLE `user`(
    `account` CHAR(30) NOT NULL,
    `username` VARCHAR(255) NOT NULL,
    `password` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `gender` VARCHAR(10) NOT NULL,
    `birth` DATE NOT NULL,
    `phonenumber` VARCHAR(30) NOT NULL
);
ALTER TABLE
    `user` ADD PRIMARY KEY(`account`);
CREATE TABLE `mylibrary`(
    `user_account` CHAR(30) NOT NULL,
    `book_number` VARCHAR(100) NOT NULL,
    `book_name` VARCHAR(100) NOT NULL,
    `purchase_date` DATE NOT NULL,
    `purchase_price` BIGINT NOT NULL
);
ALTER TABLE
    `mylibrary` ADD PRIMARY KEY(`user_account`);
CREATE TABLE `review`(
    `username` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `review_detail` TEXT NOT NULL,
    `scope` BIGINT NOT NULL,
    `review_date` DATE NOT NULL,
    `book_number` INT NOT NULL
);
CREATE TABLE `book`(
    `number` VARCHAR(100) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `author` VARCHAR(50) NOT NULL,
    `publisher` VARCHAR(50) NOT NULL,
    `publishdate` DATE NOT NULL,
    `price` INT NOT NULL,
    `description` TEXT NOT NULL,
    `image` VARCHAR(255) NOT NULL,
    `genre` VARCHAR(255) NOT NULL
);
ALTER TABLE
    `book` ADD PRIMARY KEY(`number`);

ALTER TABLE
    `book` ADD CONSTRAINT `book_name_foreign` FOREIGN KEY(`name`) REFERENCES `mylibrary`(`book_name`);
ALTER TABLE
    `user` ADD CONSTRAINT `user_username_foreign` FOREIGN KEY(`username`) REFERENCES `review`(`username`);
ALTER TABLE
    `mylibrary` ADD CONSTRAINT `mylibrary_book_number_foreign` FOREIGN KEY(`book_number`) REFERENCES `book`(`number`);
ALTER TABLE
    `review` ADD CONSTRAINT `review_book_number_foreign` FOREIGN KEY(`book_number`) REFERENCES `book`(`number`);
ALTER TABLE
    `mylibrary` ADD CONSTRAINT `mylibrary_user_account_foreign` FOREIGN KEY(`user_account`) REFERENCES `user`(`account`);


-- drop table 할때 외래키 오류시 외래키 삭제 방법
-- ALTER TABLE mylibrary DROP FOREIGN KEY mylibrary_book_number_foreign;

mysql --local-infile=1 -u root -p

LOAD DATA LOCAL INFILE 'C:\bookdb.csv'
INTO TABLE book
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;